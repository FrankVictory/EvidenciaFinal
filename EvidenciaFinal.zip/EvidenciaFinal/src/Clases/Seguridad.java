/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author pacov
 */
public class Seguridad {

    private String UsuarioID;
    private String Usuario;
    private String Contrasena;
    private String ContrasenaA;
    
    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getContrasena() {
        return Contrasena;
    }

    public void setContrasena(String Contrasena) {
        this.Contrasena = Contrasena;
    }

    public String getContrasenaA() {
        return ContrasenaA;
    }

    public void setContrasenaA(String ContrasenaA) {
        this.ContrasenaA = ContrasenaA;
    }
    
    public String getUsuarioID() {
        return UsuarioID;
    }

    public void setUsuarioID(String UsuarioID) {
        this.UsuarioID = UsuarioID;
    }

}
