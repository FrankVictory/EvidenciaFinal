/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.ArrayList;

/**
 *
 * @author pacov
 */
public class Doctores {
    
    private int codigo;
    private String DoctorID;
    private String NombreD;
    private String ApellidoD;
    private String CedulaD;
    private String EspecialidadD;
    private String HInicioD;
    private String HFinD;
    private ArrayList<Doctores> doctores;

    public Doctores(){
        doctores = new ArrayList();
    }
    
    public Doctores(int codigo, String NombreD, String ApellidoD, String TelefonoD, String CedulaD, String EspecialidadD,String HinicioD, String HFinD , ArrayList<Doctores> doctores){
        this.codigo = codigo;
        this.NombreD = NombreD;
        this.ApellidoD = ApellidoD;
        this.CedulaD = CedulaD;
        this.EspecialidadD = EspecialidadD;
        this.HInicioD = HInicioD;
        this.HFinD = HFinD;
    }
    
     public Doctores(int codigo, String NombreD, String ApellidoD, String TelefonoD, String CedulaD, String EspecialidadD,String HinicioD, String HFinD){
        this.codigo = codigo;
        this.NombreD = NombreD;
        this.ApellidoD = ApellidoD;
        this.CedulaD = CedulaD;
        this.EspecialidadD = EspecialidadD;
        this.HInicioD = HInicioD;
        this.HFinD = HFinD;
        doctores = new ArrayList();
    }
    
    public String getDoctorIDD() {
        return DoctorID;
    }

    public void setDoctorIDD(String DoctorID) {
        this.DoctorID = DoctorID;
    }

    public String getNombreD() {
        return NombreD;
    }

    public void setNombreD(String NombreD) {
        this.NombreD = NombreD;
    }

    public String getApellidoD() {
        return ApellidoD;
    }

    public void setApellidoD(String ApellidoD) {
        this.ApellidoD = ApellidoD;
    }

    public String getCedulaD() {
        return CedulaD;
    }

    public void setCedulaD(String CedulaD) {
        this.CedulaD = CedulaD;
    }

    public String getEspecialidadD() {
        return EspecialidadD;
    }

    public void setEspecialidadD(String EspecialidadD) {
        this.EspecialidadD = EspecialidadD;
    }

    public String getHInicioD() {
        return HInicioD;
    }

    public void setHInicioD(String HInicioD) {
        this.HInicioD = HInicioD;
    }

    public String getHFinD() {
        return HFinD;
    }

    public void setHFinD(String HFinD) {
        this.HFinD = HFinD;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDoctorID() {
        return DoctorID;
    }

    public void setDoctorID(String DoctorID) {
        this.DoctorID = DoctorID;
    }

    public ArrayList<Doctores> getDoctores() {
        return doctores;
    }

    public void setDoctores(ArrayList<Doctores> doctores) {
        this.doctores = doctores;
    }
 
    
    
}
