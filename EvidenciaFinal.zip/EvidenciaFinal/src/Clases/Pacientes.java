/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.ArrayList;

/**
 *
 * @author pacov
 */
public class Pacientes {
    
    private int codigo;
    private String PacienteID;
    private String NombreP;
    private String ApellidoP;
    private String TelefonoP;
    private String RFCP;
    private String EmailP;
    private ArrayList<Pacientes> pacientes;
    
    public Pacientes(){
        pacientes = new ArrayList();
    }
    
    public Pacientes(int codigo, String NombreP, String ApellidoP, String TelefonoP, String RFCP, String EmailP, ArrayList<Pacientes> pacientes){
        this.codigo = codigo;
        this.NombreP = NombreP;
        this.ApellidoP = ApellidoP;
        this.TelefonoP = TelefonoP;
        this.RFCP = RFCP;
        this.EmailP = EmailP;
    }
    
     public Pacientes(int codigo, String NombreP, String ApellidoP, String TelefonoP, String RFCP, String EmailP){
        this.codigo = codigo;
        this.NombreP = NombreP;
        this.ApellidoP = ApellidoP;
        this.TelefonoP = TelefonoP;
        this.RFCP = RFCP;
        this.EmailP = EmailP;
        pacientes = new ArrayList();
    }
    
    public String getPacienteID() {
        return PacienteID;
    }

    public void setPacienteID(String PacienteID) {
        this.PacienteID = PacienteID;
    }

    public String getNombreP() {
        return NombreP;
    }

    public void setNombreP(String NombreP) {
        this.NombreP = NombreP;
    }

    public String getApellidoP() {
        return ApellidoP;
    }

    public void setApellidoP(String ApellidoP) {
        this.ApellidoP = ApellidoP;
    }

    public String getTelefonoP() {
        return TelefonoP;
    }

    public void setTelefonoP(String TelefonoP) {
        this.TelefonoP = TelefonoP;
    }

    public String getRFCP() {
        return RFCP;
    }

    public void setRFCP(String RFCP) {
        this.RFCP = RFCP;
    }

    public String getEmailP() {
        return EmailP;
    }

    public void setEmailP(String EmailP) {
        this.EmailP = EmailP;
    }

    public ArrayList<Pacientes> getPacientes() {
        return pacientes;
    }

    public void setPacientes(ArrayList<Pacientes> pacientes) {
        this.pacientes = pacientes;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    
}
