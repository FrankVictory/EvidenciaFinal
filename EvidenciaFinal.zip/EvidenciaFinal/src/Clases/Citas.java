/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.ArrayList;

/**
 *
 * @author pacov
 */
public class Citas {
    
    private int codigo;
    private String PacienteID;
    private String EspecialidadC;
    private String DoctorID;
    private String HorarioC;
    private String FechaC;
    private ArrayList<Citas> citas;
    
    public Citas(){
        citas = new ArrayList();
    }
    
    public Citas(int codigo, String PacienteID, String EspecialidadC, String DoctorID, String HorarioC, String FechaC, ArrayList<Citas> citas){
        this.codigo = codigo;
        this.PacienteID = PacienteID;
        this.EspecialidadC = EspecialidadC;
        this.DoctorID = DoctorID;
        this.HorarioC = HorarioC;
        this.FechaC = FechaC;
        
    }
    
    public Citas(int codigo, String PacienteID, String EspecialidadC, String DoctorID, String HorarioC, String FechaC){
        this.codigo = codigo;
        this.PacienteID = PacienteID;
        this.EspecialidadC = EspecialidadC;
        this.DoctorID = DoctorID;
        this.HorarioC = HorarioC;
        this.FechaC = FechaC;
        citas = new ArrayList();
        
    }

    public String getPacienteID() {
        return PacienteID;
    }

    public void setPacienteID(String PacienteID) {
        this.PacienteID = PacienteID;
    }

    public String getEspecialidadC() {
        return EspecialidadC;
    }

    public void setEspecialidadC(String EspecialidadC) {
        this.EspecialidadC = EspecialidadC;
    }

    public String getDoctorID() {
        return DoctorID;
    }

    public void setDoctorID(String DoctorID) {
        this.DoctorID = DoctorID;
    }

    public String getHorarioC() {
        return HorarioC;
    }

    public void setHorarioC(String HorarioC) {
        this.HorarioC = HorarioC;
    }

    public String getFechaC() {
        return FechaC;
    }

    public void setFechaC(String FechaC) {
        this.FechaC = FechaC;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public ArrayList<Citas> getCitas() {
        return citas;
    }

    public void setCitas(ArrayList<Citas> citas) {
        this.citas = citas;
    }
    
    
}
